from django.shortcuts import render,redirect
from django.http import HttpResponse
from classroom.models import Student1
from classroom.models import Emp
from classroom.models import Testimonial


# Create your views here.
def index(request):
    data={
        'info':Student1.objects.all().values()
    }
    # if request.method=='POST':
    #     name=request.POST.get('name')
    #     course=request.POST.get('course')
    #     address=request.POST.get('address')
    #     age=request.POST.get('age')
    #     tappu=Student(name=name,course=course,address=address,age=age)
    #     tappu.save()
    return render(request,"info.html",data)
    # return render(request,"info.html")
    
# def index(request):
#     data={
#         'info':Student.objects.all().values()
#     }
#     return render(request,"info.html",data)

def saveform(request):
    if request.method=="Post":
        name=request.Post.get("t1")
        collage=request.Post.get("t2")
        age=request.Post.get("t3")
        Is_Active=request.post.get("t4")
        st=Student1(name=name,collage=collage,age=age,Is_Active=Is_Active)
        st.save()
        return render(request,"info.html")
    

        
# def deletedata(request):
#     if request.method=="Post":
#         id=request.Post.get("t5")
#         id1=Student1.objects.get(id)
#         id1.delete()
#         return render(request,'form.html')

def emp_home(request):
    emps=Emp.objects.all()
    return render(request,"home.html",{'emps':emps})
    # return render(request,"home.html")

# def addemp(request):
#     return render(request,"addEmp.html")

def addemp(request):
    if request.method=="POST":
        emp_name=request.POST.get("emp_name")
        emp_id=request.POST.get("emp_id")
        emp_phone=request.POST.get("emp_phone")
        emp_address=request.POST.get("emp_address")
        emp_working=request.POST.get("emp_working")
        emp_department=request.POST.get("emp_department")
        e=Emp()
        e.emp_name=emp_name
        e.emp_id=emp_id
        e.emp_phone=emp_phone
        e.emp_address=emp_address
        e.emp_working=emp_working
        e.emp_department=emp_department
        if e.emp_working is None:
            e.emp_working=False
        else:
            e.emp_working=True
        e.emp_department=emp_department
        e.save()
    return render(request,"addEmp.html")

def deleteemp(request,emp_id):
    emp=Emp.objects.get(pk=emp_id)
    emp.delete()
    return render(request,"home.html")

        
def updateemp(request,emp_id):
    emp=Emp.objects.get(pk=emp_id)
    return render(request,"updateEmp.html",{'emp':emp})


# def aboutus(request):
#     return render(request,"about.html")

# def contactus(request):
#     return render(request,"contact.html")

def doupdate(request,emp_id):
   if request.method=="POST":
      emp_name=request.POST.get("emp_name")
      emp_id_temp=request.POST.get("emp_id")
      emp_phone=request.POST.get("emp_phone")
      emp_address=request.POST.get("emp_address")
      emp_working=request.POST.get("emp_working")
      emp_department=request.POST.get("emp_department")
      e=Emp.objects.get(pk=emp_id)
      e.emp_name=emp_name
      e.emp_id=emp_id_temp
      e.emp_phone=emp_phone
      e.emp_address=emp_address
      e.emp_working=emp_working
      e.emp_department=emp_department
      if e.emp_working is None:
         e.emp_working=False
      else:
         e.emp_working=True
      e.save()



   return redirect("/home/")

def testimonials(request):
    testi=Testimonial.objects.all()
    return render(request,"testimonials.html",{'testi':testi})

    

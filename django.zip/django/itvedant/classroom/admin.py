from django.contrib import admin
from classroom.models import Student
from classroom.models import Emp
from classroom.models import Testimonial


class Student_info(admin.ModelAdmin):
    list_display=("name","collage","age","Is_Active")
    list_editable=("collage",)
    search_fields=("name",)
    list_filter=("Is_Active",)

class Emp_info(admin.ModelAdmin):
    list_display=("emp_name","emp_id","emp_phone","emp_working","emp_department")
    list_editable=("emp_id","emp_working",)
    search_fields=("emp_id","emp_name",)
    list_filter=("emp_working",)

# Register your models here.
admin.site.register(Student,Student_info)

admin.site.register(Emp,Emp_info)

class Emp_feedback(admin.ModelAdmin):
    list_display=("name","testimonial","picture","rating")
admin.site.register(Testimonial,Emp_feedback)


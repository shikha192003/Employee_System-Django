from django.contrib import admin
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index),
    # path("savedata/",views.emp_home),
    # path("deletedata/",views.emp_home),
    path("home/",views.emp_home),
    path("add-emp/",views.addemp),
    path("delete-emp/<int:emp_id>",views.deleteemp),
    path("update-emp/<int:emp_id>",views.updateemp),
    path("do-update/<int:emp_id>",views.doupdate),
    path("testi/",views.testimonials),
    
     
]
if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
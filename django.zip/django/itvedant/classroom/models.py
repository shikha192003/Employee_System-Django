from django.db import models

# Create your models here.
class Student(models.Model):
    name=models.CharField(max_length=200,null=True)
    collage=models.CharField(max_length=150,null=True)
    age=models.CharField(max_length=150,null=True)
    Is_Active=models.CharField(max_length=150,null=True)
    
    def __str__(self):
        return self.name
    
class Student1(models.Model):
    id=models.IntegerField(max_length=200,primary_key=True)
    name=models.CharField(max_length=200,null=True)
    collage=models.CharField(max_length=150,null=True)
    age=models.IntegerField(max_length=10,null=True)
    Is_Active=models.BooleanField(default=False,null=True)
    

class Emp(models.Model):
    emp_name=models.CharField(max_length=200,null=True)
    emp_id=models.IntegerField(max_length=10,null=True)
    emp_phone=models.CharField(max_length=10,null=True)
    emp_address=models.CharField(max_length=200,null=True)
    emp_working=models.BooleanField(default=True,null=True)
    emp_department=models.CharField(max_length=10,null=True)
def __str__(self):
    return self.emp_name
    
class Testimonial(models.Model):
    name=models.CharField(max_length=200)
    testimonial=models.TextField()
    picture=models.ImageField(upload_to="testi/")
    rating=models.IntegerField(max_length=1)
    

def __str__(self):
    return self.testimonial



    